﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _16.Subset_with_Desired_Sum
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
